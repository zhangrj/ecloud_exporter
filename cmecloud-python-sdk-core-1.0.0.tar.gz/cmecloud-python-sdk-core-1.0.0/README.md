# cmecloud-python-sdk-core


This is the core module of Chinamobile ecloud Python SDK.

Chinamobile ecloud Python SDK is the official software development kit. It makes things easy to integrate your Python application,
library, or script with Chinamobile ecloud services.

This module works on Python versions:

  * 2.7.0 and greater


Documentation:

Please visit [ecloud help center](https://ecloud.10086.cn/op-help-center)
