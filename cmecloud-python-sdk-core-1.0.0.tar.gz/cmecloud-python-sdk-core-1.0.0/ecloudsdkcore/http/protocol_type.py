# coding=utf-8

"""
HTTP协议类型
"""
HTTP = "http"
HTTPS = "https"
