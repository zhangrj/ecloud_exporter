# coding=utf-8

"""
服务网关地址
"""
guangzhou2 = "api-guangzhou-2.cmecloud.cn"
beijing1 = "api-beijing-1.cmecloud.cn"
