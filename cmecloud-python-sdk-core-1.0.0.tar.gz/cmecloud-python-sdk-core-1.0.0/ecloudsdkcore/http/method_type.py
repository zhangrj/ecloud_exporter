# coding=utf-8

"""
HTTP请求方法
"""
GET = "GET"
POST = "POST"
PUT = "PUT"
DELETE = "DELETE"
