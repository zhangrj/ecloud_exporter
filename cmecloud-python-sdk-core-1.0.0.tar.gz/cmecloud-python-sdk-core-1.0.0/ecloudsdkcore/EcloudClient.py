# coding=utf-8

from ecloudsdkcore.utils.requests import request
from ecloudsdkcore.EcloudRequest import AcsRequest
from ecloudsdkcore.acs_exception.exceptions import ClientException
from ecloudsdkcore.acs_exception import error_code
from ecloudsdkcore.acs_exception import error_msg
from ecloudsdkcore.auth.signature_tools import Signature
from ecloudsdkcore.http import protocol_type
from ecloudsdkcore.http import gateway_host


DEFAULT_SDK_CONNECTION_TIMEOUT_IN_SECONDS = 30
DEFAULT_API_GATEWAY_HOST = gateway_host.guangzhou2
DEFAULT_PROTOCOL_TYPE = protocol_type.HTTP


class AcsClient(object):
    """
    用户调用API接口的客户端，用于获取用户用于请求的凭据accessKey、accessSecret，设置基本参数如服务网关地址、http协议、端口号等，
    并且用于从用户请求的实体类中获取请求参数，并完成签名过程。最后执行发起请求的过程，并处理返回结果。
    """
    def __init__(self, access_key, access_secret,
                 api_gateway_host=None,
                 http_protocol = None,
                 port_number = '',
                 timeout=DEFAULT_SDK_CONNECTION_TIMEOUT_IN_SECONDS):
        """
        客户端初始化参数列表

        :param access_key: accessKey（string）
        :param access_secret: accessSecret（string）
        :param api_gateway_host: 服务网关地址（string）
        :param http_protocol: http协议（string）
        :param port_number: 端口号（integer）
        :param timeout: 请求超时时间，单位：秒（integer）
        """

        self.__accessKey = access_key
        self.__accessSecret = access_secret
        self._gatewayHost = api_gateway_host
        self._httpProtocol = http_protocol
        self._port = port_number
        self._timeout = timeout
        if self._gatewayHost is None:
            self._gatewayHost = DEFAULT_API_GATEWAY_HOST
        if self._gatewayHost == gateway_host.guangzhou2:
            self._httpProtocol = protocol_type.HTTP
        if self._gatewayHost == gateway_host.beijing1:
            self._httpProtocol = protocol_type.HTTPS
            self._port = 8443
        if self._httpProtocol is None:
            self._httpProtocol = DEFAULT_PROTOCOL_TYPE


    def get_credential(self):
        """
        用于获取用户凭据

        :return: AccessKey and AccessSecret
        """
        return {'AccessKey': self.__accessKey, 'AccessSecret': self.__accessSecret}

    def reset_credential(self, new_access_key, new_access_secret):
        """
        用于设置、更新用户凭据

        :param new_access_key: 用户AccessKey（string）
        :param new_access_secret: 用户AccessSecret（string）
        :return:
        """
        self.__accessKey = new_access_key
        self.__accessSecret = new_access_secret

    def get_apigateway_host(self):
        """
        用于获取用户服务网关地址

        :return: _gatewayHost
        """
        return self._gatewayHost

    def set_apigateway_host(self, api_gateway_host):
        """
        用于设置、更新用户服务网关地址

        :param api_gateway_host: 用户服务网关地址（string）
        :return:
        """
        self._gatewayHost = api_gateway_host

    def get_http_protocol(self):
        """
        获取http协议

        :return: _httpProtocol
        """
        return self._httpProtocol

    def set_http_protocol(self, http_protocol):
        """
        设置、更新用户HTTP协议类型

        :param http_protocol: HTTP协议类型（string）
        :return:
        """
        self._httpProtocol = http_protocol

    def get_port(self):
        """
        获取端口号

        :return: _port
        """
        return self._port

    def set_port(self, port_number):
        """
        设置、更新端口号

        :param port_number: 端口号（integer）
        :return:
        """
        self._port = port_number

    def do_action(self, acsrequest):
        """
        用于从请求实体类获取请求参数，完成签名，并执行发起请求动作以及获取响应结果

        :param acsrequest: 请求实体类（class）
        :return: response_txt
        """
        if not isinstance(acsrequest, AcsRequest):
            raise ClientException(
                error_code.SDK_INVALID_REQUEST,
                error_msg.get_msg('SDK_INVALID_REQUEST'))
        acsrequest.set_apigateway_host(self._gatewayHost)
        acsrequest.set_http_protocol(self._httpProtocol)
        acsrequest.set_port_number(self._port)
        method_type = acsrequest.get_methodtype()
        server_path = acsrequest.get_serverpath()
        url = acsrequest.get_url()
        headers = acsrequest.get_headers()
        payload = acsrequest.get_body_param()
        query_string = acsrequest.get_query_param()
        query_string['SignatureNonce'] = acsrequest.get_signature_nonce()
        query_string['AccessKey'] = self.__accessKey
        query_string['Signature'] = Signature(self.__accessKey, self.__accessSecret).sign(method_type, query_string, server_path)
        query_params_list = ''
        for (k, v) in query_string.items():
            query_params_list += '&' + k + '=' + str(v)
        full_url = url + "?" + query_params_list.lstrip("&")
        acs_response = request(method_type, url, headers=headers, json=payload, params=query_string, timeout=self._timeout)
        acs_response.encoding='utf-8'
        # print query_string
        # print acs_response.text
        return {'query_string': query_string, 'response_txt': acs_response.text, 'full_url': full_url, 'body': payload}
