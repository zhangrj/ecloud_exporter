# coding=utf-8

"""
错误码
"""
SDK_INVALID_REGION_ID = 'SDK.InvalidRegionId'
SDK_SERVER_UNREACHABLE = 'SDK.ServerUnreachable'
SDK_INVALID_REQUEST = 'SDK.InvalidRequest'
SDK_UNKNOWN_SERVER_ERROR = 'SDK.UnknownServerError'
SDK_INVALID_CREDENTIAL = 'SDK.InvalidCredential'
SDK_INVALID_SESSION_EXPIRATION = 'SDK.InvalidSessionExpiration'
SDK_GET_SESSION_CREDENTIAL_FAILED = 'SDK.GetSessionCredentialFailed'
SDK_INVALID_PARAMS = 'SDK.InvalidParams'
SDK_NOT_SUPPORT = 'SDK.NotSupport'
