# coding=utf-8

"""
错误信息
"""
__dict = dict(
    SDK_INVALID_API_GTEWAY_HOST='Can not find api-gateway host to access.',
    SDK_INVALID_API_SERVER_PATH='Can not find api-server path to access.',
    SDK_SERVER_UNREACHABLE='Unable to connect server',
    SDK_INVALID_REQUEST='The request is not a valid AcsRequest.',
    SDK_UNKNOWN_SERVER_ERROR="Can not parse error message from server response.",
    SDK_INVALID_CREDENTIAL="Need a ak&secret pair or public_key_id&private_key pair to auth.",
    SDK_INVALID_SESSION_EXPIRATION="Session expiration must between {} and {} seconds")


def get_msg(code):
    """
    获取错误信息

    :param code: 错误代码（string）
    :return:
    """
    return __dict.get(code)
