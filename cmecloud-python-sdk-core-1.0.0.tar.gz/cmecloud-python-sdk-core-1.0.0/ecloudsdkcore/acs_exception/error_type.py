# coding=utf-8

"""
错误类型
"""
ERROR_TYPE_CLIENT = 'Client'
ERROR_TYPE_SERVER = 'Server'
ERROR_TYPE_THROTTLING = 'Throttling'
ERROR_TYPE_UNKNOWN = 'Unknown'
