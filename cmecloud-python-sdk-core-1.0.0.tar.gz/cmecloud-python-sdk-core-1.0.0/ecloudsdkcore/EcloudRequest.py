# coding=utf-8

from ecloudsdkcore.http import protocol_type
from ecloudsdkcore.http import format_type
from ecloudsdkcore.acs_exception import exceptions
from ecloudsdkcore.acs_exception import error_code
import abc
import random


class AcsRequest(object):
    """
    AcsRequest请求基类，封装公共请求参数，以及各种参数的获取、设置、更新通用方法
    """
    __metaclass__ = abc.ABCMeta

    def __init__(self, method_type, server_path):
        """
        继承自该类的子类的参数初始化列表必须包含HTTP请求方法method_type和API请求路径server_path这两个参数

        :param method_type: HTTP请求方法（string）：GET、POST、DELETE、PUT
        :param server_path: API请求路径（string）
        :return:
        """
        self._accessKey = None
        self._methodType = method_type
        self._httpProtocol = None
        self._gatewayHost = None
        self._port = ''
        self._Version = '2016-12-05'
        self._serverPath = server_path
        self._pathParam = {}
        self._Timestamp = None
        self._Signature = None
        self._SignatureMethod = 'HmacSHA1'
        self._SignatureNonce = None
        self._SignatureVersion = 'V2.0'
        self._headers = {}
        self.add_header('Content-type', format_type.APPLICATION_JSON)
        self._queryString = {"Version": self._Version, "AccessKey": self._accessKey, "Timestamp": self._Timestamp,
                             "Signature": self._Signature, "SignatureMethod": self._SignatureMethod,
                             "SignatureNonce": self._SignatureNonce, "SignatureVersion": self._SignatureVersion}
        self._payload = {}

    def get_version(self):
        """
        获取API版本号

        :return: _Version
        """
        return self._Version

    def get_signature_method(self):
        """
        获取签名方法信息

        :return: _SignatureMethod
        """
        return self._SignatureMethod

    def get_signature_version(self):
        """
        获取签名版本号

        :return: _SignatureVersion
        """
        return self._SignatureVersion

    def get_signature_nonce(self):
        """
        获取签名随机数

        :return: _SignatureNonce
        """
        self._SignatureNonce = random.randint(1, 999)
        return self._SignatureNonce

    def get_apigateway_host(self):
        """
        获取API服务网关地址

        :return: _gatewayHost
        """
        return self._gatewayHost

    def set_apigateway_host(self, host_name):
        """
        设置、更新API服务网关地址

        :param host_name: API服务网关地址（string）
        :return:
        """
        self._gatewayHost = host_name

    def get_http_protocol(self):
        """
        获取HTTP协议

        :return: HTTP协议
        """
        return self._httpProtocol

    def set_http_protocol(self, protocol_name):
        """
        设置更新HTTP协议，并判定协议类型是否合法

        :param protocol_name: HTTP协议类型（string）
        :return: _httpProtocol
        """
        if protocol_name == protocol_type.HTTP or protocol_name == protocol_type.HTTPS:
            self._httpProtocol = protocol_name
        else:
            raise exceptions.ClientException(
                error_code.SDK_INVALID_PARAMS,
                "Invalid 'protocol_type', should be 'http' or 'https'"
            )

    def get_port_number(self):
        """
        获取端口号

        :return: _port
        """
        return self._port

    def set_port_number(self, port_number):
        """
        设置、更新端口号

        :param port_number: 端口号（integer）
        :return:
        """
        self._port = port_number

    def add_header(self, k, v):
        """
        添加、更新请求头信息

        :param k: key（string）
        :param v: value（string）
        :return:
        """
        self._headers[k] = v

    def get_headers(self):
        """
        获取请求头信息

        :return: _headers
        """
        return self._headers

    def set_headers(self, headers):
        """
        设置请求头信息

        :param headers: 请求头信息（Dictionary）
        """
        self._headers = headers

    def get_methodtype(self):
        """
        获取请求方法

        :return: _methodType
        """
        return self._methodType

    def set_methodtype(self, method):
        """
        设置、更新请求方法

        :param method:  HTTP请求方法（string）：GET、POST、DELETE、PUT
        :return:
        """
        self._methodType = method

    def get_serverpath(self):
        """
        获取API请求路径

        :return: _serverPath
        """
        return self._serverPath

    def set_serverpath(self, server_path):
        """
        设置、更新API请求路径

        :param server_path: API请求路径（string）
        :return:
        """
        self._serverPath = server_path

    def get_path_param(self):
        """
        获取路径请求参数信息

        :return: _pathParam
        """
        return self._pathParam

    def add_path_param(self, k, v):
        """
        设置、更新路径请求参数

        :param k: key（string）
        :param v: value（string）
        :return:
        """
        if self._serverPath.count("{%s}"%k) > 0:
            self._pathParam[k] = v
            self._serverPath = self._serverPath.replace("{%s}"%k, v)
        else:
            raise exceptions.ClientException(
                error_code.SDK_INVALID_PARAMS,
                "Invalid parameter, please refer to the API documentation"
            )

    def get_url(self):
        """
        获取请求URL

        :return: URL
        """
        return "%s://%s:%s%s" % (self._httpProtocol, self._gatewayHost, self._port, self._serverPath)

    def get_query_param(self):
        """
        获取路径后请求参数

        :return: _queryString
        """
        return self._queryString

    def add_query_param(self, k, v):
        """
        添加、更新路径后请求参数

        :param k: key（string）
        :param v: value（any）
        :return:
        """
        self._queryString[k] = v

    def set_query_params(self, query_params):
        """
        批量设置、更新路径后请求参数

        :param query_params: 路径后请求参数列表（Dictionary）
        :return:
        """
        self._queryString = query_params

    def get_body_param(self):
        """
        获取请求体参数信息

        :return: _payload
        """
        return self._payload

    def add_body_param(self, k, v):
        """
        添加、更新请求体参数

        :param k: key（string）
        :param v: value（any）
        :return:
        """
        self._payload[k] = v

    def set_body_params(self, body_params):
        """
        批量设置、更新请求体参数

        :param body_params: 请求体参数列表（Dictionary）
        :return:
        """
        self._payload = body_params
