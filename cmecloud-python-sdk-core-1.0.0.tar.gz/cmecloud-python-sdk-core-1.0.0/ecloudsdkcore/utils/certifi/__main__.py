from ecloudsdkcore.utils.certifi import where
print(where())
