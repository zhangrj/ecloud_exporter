# coding=utf-8

import hmac
from hashlib import sha1
from hashlib import sha256
import urllib
import copy
import time


def percent_encode(encode_string):
    """
    按照ecloud中API适用要求，对字符串进行编码处理

    :param encode_string: 编码字符串
    :return:
    """
    encode_string = str(encode_string)
    res = urllib.quote(encode_string, '')
    # quote对字母、'.'、'-'、'_'、'~'不转码
    # '空格'转为'%20'（quote_plus把'空格'转为'+'），'*'转为'%2A'，'+'转为'%2B'，'%'转换为'%25'
    # 实际上按照ecloud中API适用要求，在Python中不需要后面的三行替代过程。
    res = res.replace('+', '%20')
    res = res.replace('*', '%2A')
    res = res.replace('%7E', '~')
    return res


class Signature(object):
    """
    用户签名机制
    """
    def __init__(self, access_key, secret_key):
        self.access_key = access_key
        self.secret_key = secret_key

    # 签名
    def sign(self, http_method, query_string, servlet_path):
        """
        签名方法

        :param http_method: HTTP请求方法（string）
        :param query_string: 请求参数字典（Dictionary）
        :param servlet_path: API请求地址（string）
        :return: signature
        """
        time_str = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.localtime())
        query_string['Timestamp'] = time_str
        query_parameters = copy.deepcopy(query_string)
        query_parameters.pop('Signature')
        sorted_parameters = sorted(query_parameters.items(), key=lambda parameters: parameters[0])
        canonicalized_query_string = ''
        for (k, v) in sorted_parameters:
            canonicalized_query_string += '&' + percent_encode(k) + '=' + percent_encode(v)

        string_to_sign = http_method + '\n' \
                         + percent_encode(servlet_path) + '\n' \
                         + sha256(canonicalized_query_string[1:].encode('utf-8')).hexdigest()

        key = ("BC_SIGNATURE&" + self.secret_key).encode('utf-8')

        string_to_sign = string_to_sign.encode('utf-8')
        signature = hmac.new(key, string_to_sign, sha1).hexdigest()
        return signature
