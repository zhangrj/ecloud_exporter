# coding=utf-8


class AccessCredential(object):
    """
    用户凭据
    """
    def __init__(self, access_key_id, access_key_secret):
        self.access_key_id = access_key_id
        self.access_key_secret = access_key_secret

    def get_credential(self):
        credential = {"AccessKeyId": self.access_key_id, "AcceKeySecret": self.access_key_secret}
        return credential
